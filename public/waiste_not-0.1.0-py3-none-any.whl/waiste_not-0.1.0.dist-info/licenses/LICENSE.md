# WAIste Not — Proprietary License Agreement

**Effective date:** 2026-04-11
**Licensor:** Rhett Dillard Wike ("AIIT-THRESI Research Initiative"), Bristow, Oklahoma
**Product:** WAIste Not — AI Print Formation

This is a commercial software license. It is **not** open source. Reading the source for educational purposes is allowed. Copying, redistributing, or running the software commercially without a valid license key is not.

---

## 1. Grant

Upon payment of the applicable royalty (see §3), Licensor grants Licensee a non-exclusive, non-transferable, perpetual right to:

- Install WAIste Not on **one** machine identified by its machine fingerprint (CPU + primary MAC hash).
- Use WAIste Not to calibrate and print to up to **N** printers, where N is the printer count encoded in the license key.
- Render any number of documents, in any template shipped with the version purchased, without per-document fees.
- Receive all templates shipped at the time of purchase for the lifetime of the purchased version.

## 2. Restrictions

Licensee may not:

- Redistribute, sublicense, sell, lease, or host WAIste Not for use by third parties.
- Reverse-engineer the license key format in order to forge keys.
- Use WAIste Not to violate the intellectual property rights of others (e.g., fake letterhead, forged signatures, counterfeit documents).
- Circumvent the machine fingerprint binding by spoofing hardware identifiers.

Violations automatically terminate this license.

## 3. Royalty — $5 per printer

- **Per-printer royalty:** $5.00 USD per printer, one-time, paid to Licensor at activation.
- **Small business unlimited:** $499.00 USD one-time for unlimited printers on one machine.
- **Enterprise:** individually negotiated for multi-office deployments.
- **Trial:** Free use, up to 2 printers, for 7 days. All output is watermarked "WAIste Not — Unlicensed Trial."

Payment is made directly to Licensor via the activation URL, check, or other arrangement agreed in writing. The license key is delivered by email within 24 hours of receipt of payment + machine fingerprint.

## 4. Updates

- **Security fixes** to the purchased version are free for life.
- **New templates** released after purchase are available by annual update subscription ($49/year) or by re-purchase of the new version.

## 5. Warranty disclaimer

WAIste Not is provided "AS IS." Licensor makes no warranty of fitness for a particular purpose, merchantability, or non-infringement. Licensee's sole remedy in the event of defect is a refund of the royalty paid.

Licensor is not liable for:
- Ink, paper, or time wasted by miscalibration.
- Data loss from operating system or printer driver failures.
- Printer hardware damage from driver-level interactions.
- Any consequential or incidental damages whatsoever.

Maximum total liability is the royalty paid. For a $5 royalty, maximum total liability is five US dollars.

## 6. Privacy

WAIste Not is **offline-first**. Licensor does not collect, transmit, or store any Licensee data at runtime. The only network traffic Licensor's software initiates is (optional) license activation when Licensee chooses to register a key online. All calibration data, brand assets, templates, and rendered documents remain on the Licensee's machine at all times.

## 7. Termination

This license terminates automatically if Licensee breaches §2. Licensor may terminate for cause on 30 days' written notice. Upon termination, Licensee must delete all copies of WAIste Not from the licensed machine.

## 8. Governing law

This agreement is governed by the laws of the State of Oklahoma, USA. Any dispute arising under this license is subject to the exclusive jurisdiction of the state and federal courts located in Creek County, Oklahoma.

---

*By activating a WAIste Not license key on your machine, you accept these terms.*
*By running WAIste Not in trial mode, you accept §§2, 5, 6, 7.*

**Contact:** reliablerestaurantrepair@gmail.com
