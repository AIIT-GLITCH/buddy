"""
WAIste Not — Flask web UI v0.

Runs on localhost:8478. Single-machine, single-user. No auth. The UI is a
thin wrapper over the CLI commands so offices never see a terminal.

Pages:
    /            → dashboard (license status + printer count + template count)
    /printers    → list printers, add printer, calibrate
    /templates   → list templates, preview, test-print, render
    /brand       → edit brand.json (org name, address, signature, colors)
    /license     → license status + activate + fingerprint
    /preview/<template>?printer=X → live PNG render (no ink)

Entry point:
    waiste-not serve [--port 8478] [--host 127.0.0.1]
"""
from __future__ import annotations

import base64
import hmac
import html as _html
import json
import os
import secrets
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

from flask import Flask, Response, abort, jsonify, redirect, request, session, url_for

from waiste_not import license as _lic
from waiste_not.cli import (
    BRAND_FILE,
    LICENSE_FILE,
    ROOT,
    STATE_FILE,
    TEMPLATES,
    TEST_OUT,
    ensure_calib,
    html_to_pdf,
    load_brand,
    load_state,
    license_gate,
    lp_print,
    pdf_to_png,
    render_template,
    resolve_printer,
    save_state,
    parse_correction,
    validate_template_name,
)

app = Flask(__name__)
app.secret_key = os.environ.get("WAISTE_NOT_FLASK_SECRET", secrets.token_hex(32))

_PRINT_WINDOW_SECONDS = 60
_PRINT_LIMIT = 10
_PRINT_HITS: list[float] = []


def csrf_token() -> str:
    token = session.get("_csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["_csrf_token"] = token
    return token


def csrf_input() -> str:
    return f'<input type="hidden" name="_csrf_token" value="{_html.escape(csrf_token())}">'


@app.before_request
def check_csrf() -> None:
    if request.method != "POST":
        return
    expected = session.get("_csrf_token", "")
    supplied = request.form.get("_csrf_token", "")
    if not expected or not hmac.compare_digest(expected, supplied):
        abort(400)


@app.after_request
def security_headers(response):
    response.headers["Content-Security-Policy"] = "default-src 'self' 'unsafe-inline'; img-src 'self' data:"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    return response


def print_rate_limited() -> bool:
    now = time.monotonic()
    cutoff = now - _PRINT_WINDOW_SECONDS
    _PRINT_HITS[:] = [t for t in _PRINT_HITS if t >= cutoff]
    if len(_PRINT_HITS) >= _PRINT_LIMIT:
        return True
    _PRINT_HITS.append(now)
    return False

# ---------------------------------------------------------------------------
# Minimal inline CSS + layout so we don't need static files
# ---------------------------------------------------------------------------

BASE_CSS = """
* { box-sizing: border-box; }
body { font-family: -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
       margin: 0; padding: 0; background: #f5f5f3; color: #222; }
header { background: #111; color: #fff; padding: 14px 24px;
         display: flex; align-items: center; gap: 18px; }
header h1 { margin: 0; font-size: 18px; letter-spacing: 0.5px; }
header .tag { font-style: italic; font-size: 12px; color: #aaa; }
nav { display: flex; gap: 14px; margin-left: auto; }
nav a { color: #fff; text-decoration: none; font-size: 14px;
        padding: 6px 12px; border-radius: 4px; }
nav a:hover { background: #333; }
main { max-width: 1100px; margin: 24px auto; padding: 0 24px; }
h2 { border-bottom: 2px solid #111; padding-bottom: 6px; margin-top: 32px; }
.card { background: #fff; border: 1px solid #ddd; border-radius: 6px;
        padding: 16px 20px; margin: 14px 0; }
.card h3 { margin: 0 0 10px 0; }
.row { display: flex; gap: 16px; flex-wrap: wrap; }
.col { flex: 1; min-width: 280px; }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 8px 10px; text-align: left; border-bottom: 1px solid #eee; }
th { background: #fafafa; font-weight: 600; font-size: 13px; }
button, input[type=submit] {
    background: #111; color: #fff; border: 0; padding: 8px 14px;
    border-radius: 4px; cursor: pointer; font-size: 14px;
}
button.ghost { background: #fff; color: #111; border: 1px solid #111; }
input[type=text], input[type=email], textarea {
    width: 100%; padding: 8px 10px; border: 1px solid #bbb; border-radius: 4px;
    font-size: 14px; font-family: inherit;
}
.pill { display: inline-block; padding: 3px 10px; border-radius: 12px;
        font-size: 12px; font-weight: 600; }
.pill.licensed { background: #d4edda; color: #155724; }
.pill.trial    { background: #fff3cd; color: #856404; }
.pill.expired  { background: #f8d7da; color: #721c24; }
.small { font-size: 12px; color: #666; }
.preview-img { max-width: 100%; border: 1px solid #ccc; margin-top: 10px; }
form { margin: 0; }
"""


def page(title: str, body_html: str) -> str:
    state = _lic.status(LICENSE_FILE, ROOT / ".trial_start")
    mode = state["mode"]
    mode_html = f'<span class="pill {mode}">{mode.upper()}</span>'
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{title} · WAIste Not</title>
<style>{BASE_CSS}</style></head>
<body>
<header>
  <h1>WAIste Not</h1>
  <span class="tag">AI Print Formation · $5 / printer</span>
  <nav>
    <a href="/">Dashboard</a>
    <a href="/printers">Printers</a>
    <a href="/templates">Templates</a>
    <a href="/brand">Brand</a>
    <a href="/license">License {mode_html}</a>
  </nav>
</header>
<main>
<h2>{title}</h2>
{body_html}
</main>
</body></html>"""


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
def dashboard():
    state = load_state()
    brand = load_brand()
    lic_state = _lic.status(LICENSE_FILE, ROOT / ".trial_start")
    n_printers = sum(1 for k in state.keys() if not k.startswith("_"))
    n_templates = len([p for p in TEMPLATES.glob("*.html")])
    org = brand.get("org_name", "No organization set — edit /brand")

    body = f"""
<div class="row">
  <div class="col card">
    <h3>Organization</h3>
    <p><strong>{_html.escape(org)}</strong></p>
    <p class="small">{_html.escape(brand.get('address_line_1', ''))}</p>
  </div>
  <div class="col card">
    <h3>License</h3>
    <p>Mode: <span class="pill {lic_state['mode']}">{lic_state['mode'].upper()}</span></p>
    <p class="small">Printers allowed: {lic_state['printers_allowed']}</p>
    {f"<p class='small'>Days remaining: {lic_state.get('days_remaining', '?')}</p>" if lic_state['mode'] == 'trial' else ''}
    <p><a href="/license">Manage license →</a></p>
  </div>
  <div class="col card">
    <h3>Inventory</h3>
    <p>{n_printers} printer(s) calibrated</p>
    <p>{n_templates} template(s) available</p>
    <p><a href="/printers">Manage printers →</a> &nbsp; <a href="/templates">Browse templates →</a></p>
  </div>
</div>

<div class="card">
  <h3>Quick start</h3>
  <ol>
    <li>Edit your <a href="/brand">brand settings</a> — logo, address, signature.</li>
    <li>Add a printer on the <a href="/printers">Printers</a> page (one click calibrates).</li>
    <li>Preview a <a href="/templates">template</a> without burning ink.</li>
    <li>When alignment looks good, print for real.</li>
  </ol>
</div>
"""
    return page("Dashboard", body)


@app.route("/printers")
def printers():
    state = load_state()
    rows = []
    for name, templates in state.items():
        if name.startswith("_"):
            continue
        tcount = len([k for k in templates.keys()])
        last = ""
        for t, calib in templates.items():
            if calib.get("last_calibrated"):
                last = calib["last_calibrated"]
                break
        rows.append(f"""<tr><td>{_html.escape(name)}</td><td>{tcount}</td><td>{_html.escape(last or '—')}</td>
<td><a href="/templates?printer={_html.escape(name)}">templates</a></td></tr>""")
    table = f"""
<table>
<thead><tr><th>Printer</th><th>Templates</th><th>Last calibrated</th><th></th></tr></thead>
<tbody>{"".join(rows) or '<tr><td colspan=4 class=small>No printers yet.</td></tr>'}</tbody>
</table>
"""
    body = f"""
<div class="card">
  <p>Printers on this machine that WAIste Not knows about. Add a new printer by calibrating a template against it.</p>
  {table}
</div>

<div class="card">
  <h3>Detect printers on this machine (CUPS)</h3>
  <p class="small">Run <code>lpstat -p</code> in your terminal. Copy a printer name and add it by running its first calibration.</p>
</div>
"""
    return page("Printers", body)


@app.route("/templates")
def templates_page():
    try:
        printer = resolve_printer(request.args.get("printer"))
    except SystemExit as e:
        return page("Invalid printer", f"<div class='card'><p>{_html.escape(str(e))}</p></div>")
    state = load_state()
    available = sorted(p.stem for p in TEMPLATES.glob("*.html"))
    rows = []
    for t in available:
        calibrated = "✓" if printer in state and t in state[printer] else "—"
        rows.append(f"""<tr>
<td><strong>{_html.escape(t)}</strong></td>
<td>{calibrated}</td>
<td>
  <a href="/preview/{_html.escape(t)}?printer={_html.escape(printer)}"><button class="ghost">Preview</button></a>
  <form method="POST" action="/print/{_html.escape(t)}" style="display:inline">
    {csrf_input()}
    <input type="hidden" name="printer" value="{_html.escape(printer)}">
    <button>Print Test</button>
  </form>
</td>
</tr>""")
    body = f"""
<div class="card">
  <p>Currently viewing templates for <strong>{_html.escape(printer)}</strong>.</p>
  <table>
    <thead><tr><th>Template</th><th>Calibrated</th><th>Actions</th></tr></thead>
    <tbody>{"".join(rows)}</tbody>
  </table>
</div>

<div class="card">
  <h3>Fix a template (grid grammar)</h3>
  <form method="POST" action="/fix">
    {csrf_input()}
    <input type="hidden" name="printer" value="{_html.escape(printer)}">
    <div class="row">
      <div class="col"><label>Template<br><input type="text" name="template" placeholder="letter"></label></div>
      <div class="col"><label>Correction<br><input type="text" name="correction" placeholder="signature → 10c"></label></div>
    </div>
    <p><button>Apply fix</button></p>
  </form>
</div>
"""
    return page("Templates", body)


@app.route("/preview/<template>")
def preview(template):
    try:
        template = validate_template_name(template)
        printer = resolve_printer(request.args.get("printer"))
    except SystemExit as e:
        return page("Preview error", f"<div class='card'><p>{_html.escape(str(e))}</p></div>")

    allowed, watermark, lic_state = license_gate(printer, "preview")
    if not allowed:
        return page("Preview blocked", "<div class='card'><p>Trial expired or printer limit reached. Activate a license.</p></div>")

    state = load_state()
    try:
        calib, created = ensure_calib(state, printer, template)
        if created:
            save_state(state)
    except SystemExit as e:
        return page("Preview error", f"<div class='card'><p>{_html.escape(str(e))}</p></div>")

    html = render_template(template, calib, printer, with_grid=True, watermark=watermark)
    TEST_OUT.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf = TEST_OUT / f"{template}_WEB_PREVIEW_{stamp}.pdf"
    html_to_pdf(html, pdf)
    png = pdf_to_png(pdf, dpi=140)
    png_b64 = base64.b64encode(png.read_bytes()).decode()

    body = f"""
<div class="card">
  <h3>{_html.escape(template)} on {_html.escape(printer)}</h3>
  <p class="small">Dry-run preview (no ink used). License mode: <span class="pill {lic_state['mode']}">{lic_state['mode']}</span></p>
  <img class="preview-img" src="data:image/png;base64,{png_b64}" alt="preview">
</div>

<div class="card">
  <h3>Apply a correction</h3>
  <form method="POST" action="/fix">
    {csrf_input()}
    <input type="hidden" name="template" value="{_html.escape(template)}">
    <input type="hidden" name="printer" value="{_html.escape(printer)}">
    <label>Correction (grid grammar)<br>
      <input type="text" name="correction" placeholder="signature → 10c, or: flip lr, or: shift up 1">
    </label>
    <p><button>Apply fix</button></p>
  </form>
</div>
"""
    return page(f"Preview: {template}", body)


@app.route("/fix", methods=["POST"])
def fix():
    try:
        template = validate_template_name(request.form.get("template", "").strip())
        printer = resolve_printer(request.form.get("printer"))
    except SystemExit as e:
        return page("Fix failed", f"<div class='card'><p>{_html.escape(str(e))}</p></div>")
    correction = request.form.get("correction", "").strip()
    if not (template and correction):
        return page("Fix failed", "<div class='card'>template and correction are required</div>")
    state = load_state()
    try:
        calib, _created = ensure_calib(state, printer, template)
    except SystemExit as e:
        return page("Fix failed", f"<div class='card'><p>{_html.escape(str(e))}</p></div>")
    msgs = parse_correction(calib, correction)
    save_state(state)
    body = f"""
<div class="card">
  <h3>✓ Applied</h3>
  <ul>{"".join(f"<li>{_html.escape(m)}</li>" for m in msgs)}</ul>
  <p><a href="/preview/{_html.escape(template)}?printer={_html.escape(printer)}">Re-preview →</a></p>
</div>
"""
    return page("Fix applied", body)


@app.route("/print/<template>", methods=["POST"])
def print_template(template):
    if print_rate_limited():
        return page("Print blocked", "<div class='card'><p>Too many print requests. Wait a minute and try again.</p></div>")
    try:
        template = validate_template_name(template)
        printer = resolve_printer(request.form.get("printer"))
    except SystemExit as e:
        return page("Print failed", f"<div class='card'><p>{_html.escape(str(e))}</p></div>")

    allowed, watermark, _lic_state = license_gate(printer, "test")
    if not allowed:
        return page("Print blocked", "<div class='card'><p>Trial expired or printer limit reached. Activate a license.</p></div>")

    state = load_state()
    try:
        calib, created = ensure_calib(state, printer, template)
        if created:
            save_state(state)
    except SystemExit as e:
        return page("Print failed", f"<div class='card'><p>{_html.escape(str(e))}</p></div>")

    html = render_template(template, calib, printer, with_grid=True, watermark=watermark)
    TEST_OUT.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf = TEST_OUT / f"{template}_WEB_TEST_{stamp}.pdf"
    html_to_pdf(html, pdf)
    try:
        lp_print(pdf, printer)
        msg = f"Sent to printer {printer} (template {template})."
    except SystemExit as e:
        msg = f"lp failed: {e}"
    return page("Print dispatched", f"<div class='card'><p>{_html.escape(msg)}</p></div>")


@app.route("/brand", methods=["GET", "POST"])
def brand():
    brand_data = load_brand()
    if request.method == "POST":
        for key in (
            "org_name", "org_tagline",
            "address_line_1", "address_line_2",
            "phone", "email", "website",
            "signature_name", "signature_title",
            "primary_color", "accent_color",
            "golden_footer",
        ):
            brand_data[key] = request.form.get(key, brand_data.get(key, ""))
        BRAND_FILE.write_text(json.dumps(brand_data, indent=2) + "\n")
        return redirect(url_for("brand"))

    def input_field(key, label, multiline=False):
        val = _html.escape(brand_data.get(key, ""))
        if multiline:
            return f"<label>{label}<br><textarea name='{key}' rows='4'>{val}</textarea></label><br><br>"
        return f"<label>{label}<br><input type='text' name='{key}' value='{val}'></label><br><br>"

    body = f"""
<div class="card">
  <p>This is your organization's single source of truth. Every template pulls from here. Change your address once, every letter updates.</p>
  <form method="POST">
    {csrf_input()}
    <div class="row">
      <div class="col">
        {input_field('org_name', 'Organization name')}
        {input_field('org_tagline', 'Tagline / subhead')}
        {input_field('address_line_1', 'Address line 1')}
        {input_field('address_line_2', 'Address line 2')}
        {input_field('phone', 'Phone')}
        {input_field('email', 'Email')}
        {input_field('website', 'Website')}
      </div>
      <div class="col">
        {input_field('signature_name', 'Signature — name')}
        {input_field('signature_title', 'Signature — title')}
        {input_field('primary_color', 'Primary color (hex)')}
        {input_field('accent_color', 'Accent color (hex)')}
        {input_field('golden_footer', 'Footer block', multiline=True)}
      </div>
    </div>
    <p><button>Save brand settings</button></p>
  </form>
</div>
"""
    return page("Brand settings", body)


@app.route("/license", methods=["GET", "POST"])
def license_page():
    if request.method == "POST":
        key = request.form.get("key", "").strip()
        try:
            _lic.save_license(LICENSE_FILE, key)
            msg = "✓ License activated."
        except ValueError as e:
            msg = f"Activation failed: {e}"
    else:
        msg = ""

    state = _lic.status(LICENSE_FILE, ROOT / ".trial_start")
    fp = _lic.machine_fingerprint()
    calib_state = load_state()
    current_printers = [k for k in calib_state.keys() if not k.startswith("_")]

    body = f"""
<div class="card">
  <h3>License state</h3>
  <p>Mode: <span class="pill {state['mode']}">{state['mode'].upper()}</span></p>
  <p>Machine fingerprint: <code>{fp}</code></p>
  <p>Printers allowed: <strong>{state['printers_allowed']}</strong></p>
  <p>Printers active: <strong>{len(current_printers)}</strong> — {", ".join(current_printers) or "none"}</p>
  {f"<p>Days remaining in trial: <strong>{state.get('days_remaining', 0)}</strong></p>" if state['mode'] == 'trial' else ''}
  {f"<p>Email: <code>{_html.escape(state.get('email', ''))}</code></p>" if state['mode'] == 'licensed' else ''}
</div>

<div class="card">
  <h3>Activate a license</h3>
  <p class="small">Send the machine fingerprint above to the vendor with your payment ($5 / printer). You'll receive a WN1-... key in return.</p>
  {f"<p><strong>{msg}</strong></p>" if msg else ''}
  <form method="POST">
    {csrf_input()}
    <label>License key<br>
      <input type="text" name="key" placeholder="WN1-...-...">
    </label>
    <p><button>Activate</button></p>
  </form>
</div>
"""
    return page("License", body)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def serve(host: str = "127.0.0.1", port: int = 8478) -> None:
    print(f"WAIste Not — web UI serving at http://{host}:{port}")
    app.run(host=host, port=port, debug=False)


if __name__ == "__main__":
    serve()
