#!/usr/bin/env python3
"""
calibrate.py — Rhet ↔ Claude print calibration tool

Shared-grid coordinate system for talking about where things are on a printed
page. See GRID_PROTOCOL.md for the full spec.

Usage:
    calibrate.py list
    calibrate.py show <template> [--printer NAME]
    calibrate.py test <template> [--printer NAME] [--no-print]
    calibrate.py fix <template> "<correction>" [--printer NAME]
    calibrate.py render <template> --content FILE.md --out OUT.pdf [--printer NAME]

The 'test' command renders the template with a grid overlay, sends it to the
printer, and saves a PDF copy to test_output/ so Rhet can mark it up and tell
Claude what to fix in grid coordinates.

The 'fix' command parses corrections in the grammar:
    "9a → 10c"                    move thing at 9a to 10c
    "move signature to 10c"        move named element
    "1a=letterhead, 7d=body"      assign regions
    "flip lr"                      mirror layout horizontally
    "shift up 1" / "shift right 2" move whole layout
    "too tight at 5c"              flag tight margins
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

# Path resolution: WAISTE_NOT_HOME env var → ~/.waiste_not/ → project root (dev mode)
_PKG_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _PKG_DIR.parent
_DEFAULTS = _PKG_DIR / "defaults"


def _copy_missing(src: Path, dst: Path) -> None:
    if dst.exists():
        return
    if src.is_dir():
        shutil.copytree(src, dst)
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def _ensure_runtime_root(root: Path) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    if _DEFAULTS.exists():
        _copy_missing(_DEFAULTS / "templates", root / "templates")
        _copy_missing(_DEFAULTS / "brand.json", root / "brand.json")
        _copy_missing(_DEFAULTS / "calibration.json", root / "calibration.json")
        _copy_missing(_DEFAULTS / "template_profiles.json", root / "template_profiles.json")
    (root / "test_output").mkdir(exist_ok=True)
    return root


def _resolve_root() -> Path:
    env = os.environ.get("WAISTE_NOT_HOME")
    if env:
        p = Path(env).expanduser()
        return _ensure_runtime_root(p)
    home = Path.home() / ".waiste_not"
    if (home / "templates").exists():
        return _ensure_runtime_root(home)
    if (_PROJECT_ROOT / "templates").exists():
        return _PROJECT_ROOT
    return _ensure_runtime_root(home)


ROOT = _resolve_root()
TEMPLATES = ROOT / "templates"
TEST_OUT = ROOT / "test_output"
STATE_FILE = ROOT / "calibration.json"
BRAND_FILE = ROOT / "brand.json"
LICENSE_FILE = ROOT / "license.key"
PROFILE_FILE = ROOT / "template_profiles.json"
DEFAULT_PRINTER = "EPSON_ET_2800_Series"

COORD_RE = re.compile(r"\b(1[0-1]|[1-9])([a-h])\b", re.IGNORECASE)
ARROW_RE = re.compile(r"(\d{1,2}[a-h])\s*(?:->|→|to)\s*(\d{1,2}[a-h])", re.IGNORECASE)
ASSIGN_RE = re.compile(r"(\d{1,2}[a-h])\s*=\s*([a-z_][a-z0-9_]*)", re.IGNORECASE)
SHIFT_RE = re.compile(r"shift\s+(up|down|left|right)\s+(\d+)", re.IGNORECASE)
MOVE_RE = re.compile(r"move\s+([a-z_][a-z0-9_]*)\s+to\s+(\d{1,2}[a-h])", re.IGNORECASE)
FLIP_RE = re.compile(r"flip\s+lr", re.IGNORECASE)
SAFE_TEMPLATE_RE = re.compile(r"^[A-Za-z0-9_-]{1,80}$")
SAFE_PRINTER_RE = re.compile(r"^[A-Za-z0-9_.@-]{1,128}$")
UNSAFE_BLOCK_RE = re.compile(r"<(script|style|iframe|object|embed|link|meta)\b[^>]*>.*?</\1\s*>", re.IGNORECASE | re.DOTALL)
UNSAFE_TAG_RE = re.compile(r"</?(script|style|iframe|object|embed|link|meta)\b[^>]*>", re.IGNORECASE | re.DOTALL)
EVENT_ATTR_RE = re.compile(r"""\s+on[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)""", re.IGNORECASE | re.DOTALL)
JS_URL_RE = re.compile(r"""\s+(href|src)\s*=\s*(["'])\s*javascript:[^"']*\2""", re.IGNORECASE | re.DOTALL)
# Grid lines: "f|g" (vertical line between f and g), "2|3" (horizontal line between row 2 and row 3)
VLINE_RE = re.compile(r"\b([a-h])\|([a-h])\b", re.IGNORECASE)
HLINE_RE = re.compile(r"\b(\d{1,2})\|(\d{1,2})\b")


def current_system_default_printer() -> str | None:
    try:
        r = subprocess.run(["lpstat", "-d"], capture_output=True, text=True, timeout=3)
    except Exception:
        return None
    if r.returncode != 0:
        return None
    m = re.search(r"system default destination:\s*(\S+)", r.stdout)
    return m.group(1) if m else None


def resolve_printer(printer: str | None) -> str:
    if printer:
        return validate_printer_name(printer)
    return validate_printer_name(current_system_default_printer() or DEFAULT_PRINTER)


def cups_printers() -> list[str]:
    try:
        r = subprocess.run(["lpstat", "-p"], capture_output=True, text=True, timeout=3)
    except Exception:
        return []
    if r.returncode != 0:
        return []
    out: list[str] = []
    for line in r.stdout.splitlines():
        m = re.match(r"printer\s+(\S+)\s+", line)
        if m:
            out.append(m.group(1))
    return out


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def calibration_snapshot(calib: dict) -> dict:
    return {
        "flip_lr": bool(calib.get("flip_lr", False)),
        "global_offset_mm": calib.get("global_offset_mm", {"x": 0, "y": 0}),
        "last_calibrated": calib.get("last_calibrated"),
        "regions": calib.get("regions", {}),
    }


def print_calibration_summary(action: str, printer: str, template: str, calib: dict, created: bool = False) -> None:
    snap = calibration_snapshot(calib)
    off = snap["global_offset_mm"] or {"x": 0, "y": 0}
    created_note = " (created default profile)" if created else ""
    print(f"{action}: printer={printer} template={template} root={ROOT}{created_note}")
    print(f"calibration: flip_lr={snap['flip_lr']} offset_mm=({off.get('x', 0)}, {off.get('y', 0)}) last={snap['last_calibrated'] or 'never'}")


def write_job_manifest(
    kind: str,
    printer: str,
    template: str,
    calib: dict,
    outputs: dict[str, Path],
    created: bool,
    license_state: dict | None = None,
) -> Path:
    manifest = {
        "kind": kind,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "root": str(ROOT),
        "printer": printer,
        "template": template,
        "created_profile": created,
        "calibration": calibration_snapshot(calib),
        "license": license_state or {},
        "outputs": {
            name: {
                "path": str(path),
                "sha256": file_sha256(path) if path.exists() else None,
            }
            for name, path in outputs.items()
        },
    }
    anchor = next(iter(outputs.values()))
    out = anchor.with_suffix(anchor.suffix + ".manifest.json")
    out.write_text(json.dumps(manifest, indent=2) + "\n")
    return out


# ---------------------------------------------------------------------------
# state loading
# ---------------------------------------------------------------------------

def load_state() -> dict:
    if not STATE_FILE.exists():
        return {}
    return json.loads(STATE_FILE.read_text())


def save_state(state: dict) -> None:
    STATE_FILE.write_text(json.dumps(state, indent=2) + "\n")


def load_brand() -> dict:
    """Load the organization's brand config (name, address, colors, signature).

    Returns an empty dict if no brand.json exists — templates will fall back to
    whatever defaults they define.
    """
    if not BRAND_FILE.exists():
        return {}
    try:
        return json.loads(BRAND_FILE.read_text())
    except Exception:
        return {}


def validate_template_name(template: str) -> str:
    template = (template or "").strip()
    if not SAFE_TEMPLATE_RE.fullmatch(template):
        raise SystemExit(f"Invalid template name: {template!r}")
    return template


def validate_printer_name(printer: str) -> str:
    printer = (printer or "").strip()
    if not SAFE_PRINTER_RE.fullmatch(printer):
        raise SystemExit(f"Invalid printer name: {printer!r}")
    return printer


def _load_template_profiles() -> dict:
    if PROFILE_FILE.exists():
        try:
            return json.loads(PROFILE_FILE.read_text())
        except Exception:
            return {}
    return {}


def _template_profile_from_state(state: dict, template: str) -> dict | None:
    for templates in state.values():
        if isinstance(templates, dict) and template in templates:
            return json.loads(json.dumps(templates[template]))
    return None


def default_calib_for(state: dict, template: str) -> dict:
    template = validate_template_name(template)
    profiles = _load_template_profiles()
    if template in profiles:
        return json.loads(json.dumps(profiles[template]))
    from_state = _template_profile_from_state(state, template)
    if from_state is not None:
        from_state["last_calibrated"] = None
        from_state.setdefault("global_offset_mm", {"x": 0, "y": 0})
        from_state["global_offset_mm"] = {"x": 0, "y": 0}
        from_state["flip_lr"] = False
        from_state["element_overrides"] = {}
        return from_state
    raise SystemExit(f"No default calibration profile for template {template!r}.")


def get_calib(state: dict, printer: str, template: str) -> dict:
    printer = validate_printer_name(printer)
    template = validate_template_name(template)
    if printer not in state:
        raise SystemExit(f"No calibration for printer {printer!r}. Add it to calibration.json first.")
    if template not in state[printer]:
        raise SystemExit(f"No calibration for template {template!r} on {printer}. Add it to calibration.json first.")
    return state[printer][template]


def ensure_calib(state: dict, printer: str, template: str) -> tuple[dict, bool]:
    printer = validate_printer_name(printer)
    template = validate_template_name(template)
    created = False
    if printer not in state:
        state[printer] = {}
        created = True
    if template not in state[printer]:
        state[printer][template] = default_calib_for(state, template)
        created = True
    return state[printer][template], created


# ---------------------------------------------------------------------------
# license gate — resolves (allowed, watermark) for a given printer + action
# ---------------------------------------------------------------------------

def license_gate(printer: str, action: str = "render") -> tuple[bool, bool, dict]:
    """Decide whether the given printer+action is allowed under the current license.

    Returns (allowed, watermark, state_dict).
      - licensed + printer covered  → (True, False, state)
      - trial, within printer cap   → (True, True, state)   [watermarked]
      - trial, over printer cap     → (False, True, state)  [hard block]
      - expired                     → (False, True, state)  [hard block]

    `fix`, `list`, `show`, `scan` bypass this gate by not calling it.
    """
    printer = validate_printer_name(printer)
    from waiste_not import license as _lic
    trial_file = ROOT / ".trial_start"
    state = _lic.status(LICENSE_FILE, trial_file)
    calib_state = load_state()
    current_printers = [k for k in calib_state.keys() if not k.startswith("_")]

    if state["mode"] == "licensed":
        if printer in current_printers or len(current_printers) < state["printers_allowed"]:
            return True, False, state
        # Over the paid cap → upsell.
        sys.stderr.write(
            f"\n⚠️  License covers {state['printers_allowed']} printers; "
            f"{len(current_printers)} already active. Add printers at $5 each "
            f"and re-issue key.\n"
        )
        return False, True, state

    if state["mode"] == "trial":
        days = state["days_remaining"]
        cap = state["printers_allowed"]
        if printer in current_printers or len(current_printers) < cap:
            if action != "preview":
                sys.stderr.write(
                    f"ℹ️  Trial: {days} day(s) left, {cap} printers max. "
                    f"Output will carry the WAIste Not trial watermark.\n"
                )
            return True, True, state
        sys.stderr.write(
            f"\n⚠️  Trial allows {cap} printers; add a license (waiste-not license activate <KEY>).\n"
        )
        return False, True, state

    # expired
    sys.stderr.write(
        "\n⚠️  Trial expired. Activate with: waiste-not license activate <KEY>\n"
        "    Get a key from https://waiste-not.app ($5 per printer).\n"
    )
    return False, True, state


# ---------------------------------------------------------------------------
# grid coordinate helpers
# ---------------------------------------------------------------------------

def coord_to_rowcol(coord: str) -> tuple[int, int]:
    m = re.fullmatch(r"(\d{1,2})([a-h])", coord, re.IGNORECASE)
    if not m:
        raise ValueError(f"bad coordinate: {coord!r}")
    row = int(m.group(1))
    col = ord(m.group(2).lower()) - ord("a") + 1
    if not (1 <= row <= 11 and 1 <= col <= 8):
        raise ValueError(f"coordinate out of range: {coord!r}")
    return row, col


def rowcol_to_coord(row: int, col: int) -> str:
    return f"{row}{chr(ord('a') + col - 1)}"


def cell_to_mm(row: int, col: int) -> tuple[float, float]:
    """Return (x_mm, y_mm) of the top-left of cell (row, col) on letter paper."""
    col_w_mm = 8.5 * 25.4 / 8   # ~26.99 mm per column
    row_h_mm = 11.0 * 25.4 / 11  # = 25.4 mm per row
    x = (col - 1) * col_w_mm
    y = (row - 1) * row_h_mm
    return x, y


# ---------------------------------------------------------------------------
# grid overlay HTML + CSS
# ---------------------------------------------------------------------------

def grid_css(calib: dict | None = None) -> str:
    page = (calib or {}).get("page", {})
    grid = (calib or {}).get("grid", {})
    page_w = page.get("width", "8.5in")
    page_h = page.get("height", "11in")
    cols = int(grid.get("cols", 8))
    rows = int(grid.get("rows", 11))
    template = """
    .grid-overlay {
      position: fixed;
      top: 0; left: 0;
      width: __PAGE_W__; height: __PAGE_H__;
      pointer-events: none;
      z-index: 9999;
    }
    .grid-cells {
      position: absolute;
      top: 0; left: 0;
      width: 100%; height: 100%;
      display: grid;
      grid-template-columns: repeat(__COLS__, 1fr);
      grid-template-rows: repeat(__ROWS__, 1fr);
    }
    .gcell {
      border: 0.5px dashed rgba(0, 100, 200, 0.45);
      font-family: "Courier New", monospace;
      font-size: 7pt;
      color: rgba(0, 100, 200, 0.85);
      padding: 2px 3px;
      background: transparent;
      box-sizing: border-box;
    }
    .gcell.corner { background: rgba(0, 100, 200, 0.06); }

    /* === Line labels at page edges === */
    .gline {
      position: absolute;
      font-family: "Courier New", monospace;
      font-size: 6pt;
      color: rgba(180, 0, 0, 0.95);
      font-weight: bold;
      background: rgba(255, 255, 255, 0.85);
      padding: 0 2px;
      white-space: nowrap;
      transform-origin: 0 0;
    }
    .gline.top { top: 0; transform: translateX(-50%); }
    .gline.bot { bottom: 0; transform: translateX(-50%); }
    .gline.left  { left: 0;  transform: translateY(-50%); }
    .gline.right { right: 0; transform: translateY(-50%); }

    .gline-v {
      position: absolute;
      top: 0; height: 100%;
      width: 0.4pt;
      background: rgba(180, 0, 0, 0.35);
    }
    .gline-h {
      position: absolute;
      left: 0; width: 100%;
      height: 0.4pt;
      background: rgba(180, 0, 0, 0.35);
    }
    """
    return (
        template
        .replace("__PAGE_W__", page_w)
        .replace("__PAGE_H__", page_h)
        .replace("__COLS__", str(cols))
        .replace("__ROWS__", str(rows))
    )


def grid_overlay_html(calib: dict | None = None) -> str:
    grid = (calib or {}).get("grid", {})
    COLS = int(grid.get("cols", 8))
    ROWS = int(grid.get("rows", 11))
    col_labels = grid.get("col_labels") or [chr(ord("a") + i) for i in range(COLS)]
    row_labels = grid.get("row_labels") or [str(i) for i in range(1, ROWS + 1)]

    # --- cells with interior labels ---
    cells = []
    for row in range(1, ROWS + 1):
        for col in range(1, COLS + 1):
            coord = rowcol_to_coord(row, col)
            corner = " corner" if (row, col) in {(1, 1), (1, COLS), (ROWS, 1), (ROWS, COLS)} else ""
            cells.append(f'<div class="gcell{corner}">{coord}</div>')

    # --- vertical line labels (between columns), along top + bottom ---
    #  9 vertical lines: left-edge, 7 interior, right-edge
    v_lines = []
    v_indicators = []
    for i in range(COLS + 1):
        pct = (i / COLS) * 100.0
        if i == 0:
            name = f"|{col_labels[0]}"
        elif i == COLS:
            name = f"{col_labels[-1]}|"
        else:
            name = f"{col_labels[i-1]}|{col_labels[i]}"
        v_lines.append(f'<div class="gline top" style="left: {pct}%">{name}</div>')
        v_lines.append(f'<div class="gline bot" style="left: {pct}%">{name}</div>')
        v_indicators.append(f'<div class="gline-v" style="left: {pct}%"></div>')

    # --- horizontal line labels (between rows), along left + right ---
    h_lines = []
    h_indicators = []
    for i in range(ROWS + 1):
        pct = (i / ROWS) * 100.0
        if i == 0:
            name = f"|{row_labels[0]}"
        elif i == ROWS:
            name = f"{row_labels[-1]}|"
        else:
            name = f"{row_labels[i-1]}|{row_labels[i]}"
        h_lines.append(f'<div class="gline left"  style="top: {pct}%">{name}</div>')
        h_lines.append(f'<div class="gline right" style="top: {pct}%">{name}</div>')
        h_indicators.append(f'<div class="gline-h" style="top: {pct}%"></div>')

    html = ['<div class="grid-overlay">']
    html += v_indicators
    html += h_indicators
    html.append('<div class="grid-cells">')
    html += cells
    html.append("</div>")
    html += v_lines
    html += h_lines
    html.append("</div>")
    return "\n  ".join(html)


# ---------------------------------------------------------------------------
# template rendering
# ---------------------------------------------------------------------------

DUMMY_CONTENT = {
    "HEADLINE": "TEST SHEET — Letter Template",
    "SUBHEAD": "Grid calibration print · use cell coordinates to mark corrections",
    "FROM": "Rhett Dillard Wike &middot; AIIT-THRESI &middot; Bristow, Oklahoma",
    "TO": "Calibration target &middot; {printer}",
    "RE": "Print Calibration v1 · {template}",
    "DATE": "{today}",
    "BODY": """
<p>This is a test sheet for the <strong>letter</strong> template. The dashed
blue grid is the shared coordinate system. Each cell is labeled in its
upper-left corner (1a, 1b, ...). Use these labels to tell Claude what is in
the wrong place.</p>

<p class="big">Example: "move signature to 10c" or "9a → 10c"</p>

<p>The grid runs from row 1 (top) to row 11 (bottom) and from column a (left)
to column h (right). The left/right orientation matches the paper as you hold
it in your hands — <em>Claude's left has already been flipped to match</em>.
You should never have to do the mirror flip in your head again.</p>

<p>When you mark a correction, Claude will save the delta for this printer
and this template and apply it automatically on every future print. Calibrate
once, print correct forever.</p>

<p>Below is a sample signature block and IP notice so you can see where they
land on the page.</p>
""",
    "SIGNATURE_BLOCK": """
With respect and full presence,<br><br>
<span class="name">Rhett Dillard Wike</span><br>
AIIT-THRESI Research Initiative<br>
Bristow, Oklahoma<br>
reliablerestaurantrepair@gmail.com &middot; 918-636-9383
""",
    "IPNOTICE": """
<strong>Test sheet only.</strong> This page exists to calibrate the letter
template against the EPSON_ET_2800_Series printer. Nothing on this page is
content — mark it up with cell coordinates and tell Claude what to fix.
""",
}


def render_template(
    template: str,
    calib: dict,
    printer: str,
    content: dict | None = None,
    with_grid: bool = False,
    watermark: bool = False,
    recipients: list[dict] | None = None,
) -> str:
    template = validate_template_name(template)
    printer = validate_printer_name(printer)
    template_path = (TEMPLATES / f"{template}.html").resolve()
    templates_root = TEMPLATES.resolve()
    if templates_root not in template_path.parents:
        raise SystemExit(f"template path escaped templates directory: {template!r}")
    if not template_path.exists():
        raise SystemExit(f"template not found: {template_path}")
    html = template_path.read_text()

    # Page margins
    page = calib["page"]
    html = html.replace("{{MARGIN_TOP}}", page["margin_top"])
    html = html.replace("{{MARGIN_RIGHT}}", page["margin_right"])
    html = html.replace("{{MARGIN_BOTTOM}}", page["margin_bottom"])
    html = html.replace("{{MARGIN_LEFT}}", page["margin_left"])

    # Flip LR
    flip_css = "transform: scaleX(-1);" if calib.get("flip_lr") else ""
    html = html.replace("{{FLIP_LR_CSS}}", flip_css)

    # Element overrides — sig delta example
    sig_delta = ""
    overrides = calib.get("element_overrides", {})
    if "signature" in overrides:
        delta = overrides["signature"].get("delta_mm", {})
        dx = delta.get("x", 0)
        dy = delta.get("y", 0)
        if dx or dy:
            sig_delta = f"margin-left: {dx}mm; margin-top: {dy}mm;"
    html = html.replace("{{SIG_DELTA}}", sig_delta)

    # Grid
    is_avery = template.startswith("avery_")
    if is_avery:
        # Avery sheets don't use the traditional page-aligned grid; instead,
        # with_grid=True draws a faint dashed outline on each physical label cell.
        overlay_block = ""
        if with_grid:
            grid_block = (
                ".label { outline: 0.5pt dashed #4a90e2; }\n"
                ".label::before { content: attr(data-i); position: absolute; "
                "top: 1pt; right: 2pt; font-size: 5pt; color: #4a90e2; "
                "font-family: monospace; }"
            )
        else:
            grid_block = ""
    else:
        grid_block = grid_css(calib) if with_grid else ""
        overlay_block = grid_overlay_html(calib) if with_grid else ""

    # Verified stamp — always present when rendered through wAIste Not
    from waiste_not import license as _lic
    grid_block = grid_block + "\n" + _lic.verified_stamp_css()

    # Watermark (trial / expired / unlicensed-printer)
    if watermark:
        grid_block = grid_block + "\n" + _lic.watermark_css()

    html = html.replace("{{GRID_CSS}}", grid_block)
    html = html.replace("{{GRID_OVERLAY_HTML}}", overlay_block)

    # Avery label grid (30-up, 10-up, etc.)
    if is_avery:
        labels_html = build_avery_labels_html(calib, load_brand(), recipients=recipients)
        html = html.replace("{{LABELS_HTML}}", labels_html)

    # Content
    today = datetime.now().strftime("%B %-d, %Y")
    brand = load_brand()
    merged = {k: v for k, v in DUMMY_CONTENT.items()}

    # Brand-driven defaults — override dummy content when brand.json is set
    if brand:
        brand_slots = {
            "HEADLINE": _esc_html(brand.get("org_name", merged.get("HEADLINE", ""))),
            "SUBHEAD": _esc_html(brand.get("org_tagline", merged.get("SUBHEAD", ""))),
            "FROM": _brand_from_line(brand),
            "SIGNATURE_BLOCK": _brand_signature_block(brand),
            "GOLDEN_FOOTER": _esc_html(brand.get("golden_footer", merged.get("GOLDEN_FOOTER", ""))),
            # envelope slots pulled from brand
            "RETURN_NAME": _esc_html(brand.get("signature_name", "")),
            "RETURN_ORG": _esc_html(brand.get("org_name", "")),
            "RETURN_ADDRESS_1": _esc_html(brand.get("address_line_1", "")),
            "RETURN_ADDRESS_2": _esc_html(brand.get("address_line_2", "")),
        }
        for k, v in brand_slots.items():
            if v:
                merged[k] = v

    # Envelope delivery defaults (placeholder until render supplies real recipient)
    merged.setdefault("DELIVERY_NAME", "Recipient Name")
    merged.setdefault("DELIVERY_ORG", "Office or Organization")
    merged.setdefault("DELIVERY_ADDRESS_1", "123 Main Street")
    merged.setdefault("DELIVERY_ADDRESS_2", "City, ST 00000")
    merged.setdefault("DELIVERY_DELTA", "")

    if content:
        merged.update(content)

    # Substitute inner placeholders in dummy content
    for k, v in list(merged.items()):
        if isinstance(v, str):
            merged[k] = v.replace("{printer}", printer).replace("{template}", template).replace("{today}", today)

    merged["TITLE"] = merged.get("HEADLINE", f"{template} test")

    for key, val in merged.items():
        html = html.replace("{{" + key + "}}", val)

    # Any remaining placeholders → blank
    html = re.sub(r"\{\{[A-Z0-9_]+\}\}", "", html)
    return html


def _brand_from_line(brand: dict) -> str:
    """Assemble a From: line from brand config."""
    parts = []
    if brand.get("signature_name"):
        parts.append(_esc_html(brand["signature_name"]))
    if brand.get("org_name"):
        parts.append(_esc_html(brand["org_name"]))
    if brand.get("address_line_1"):
        parts.append(_esc_html(brand["address_line_1"]))
    return " · ".join(parts)


# ---------------------------------------------------------------------------
# Avery label support
# ---------------------------------------------------------------------------

def _load_recipients_csv(path: Path) -> list[dict]:
    """Read a simple CSV for Avery labels. Columns: name, line1, line2, line3.

    - line2 / line3 are optional.
    - An optional header row is auto-detected when the first cell equals
      'name' / 'recipient' / 'to' (case-insensitive).
    """
    import csv
    rows: list[dict] = []
    with open(path, newline="") as f:
        reader = csv.reader(f)
        first = True
        for r in reader:
            if not r or all(not c.strip() for c in r):
                continue
            if first:
                first = False
                if r and r[0].strip().lower() in ("name", "recipient", "to"):
                    continue
            r = (r + ["", "", "", ""])[:4]
            rows.append({
                "name": r[0].strip(),
                "line1": r[1].strip(),
                "line2": r[2].strip(),
                "line3": r[3].strip(),
            })
    return rows


def _esc_html(s: str) -> str:
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _strip_unsafe_html(html: str) -> str:
    html = UNSAFE_BLOCK_RE.sub("", html or "")
    html = UNSAFE_TAG_RE.sub("", html)
    html = EVENT_ATTR_RE.sub("", html)
    html = JS_URL_RE.sub("", html)
    return html


def build_avery_labels_html(calib: dict, brand: dict, recipients: list[dict] | None = None) -> str:
    """Render the inner HTML for an Avery sheet.

    Each label is an absolutely positioned <div class="label"> whose top/left
    are computed from the Avery product spec stored in calib['avery'].
    If `recipients` is None, all cells are filled with the brand return address.
    """
    spec = calib.get("avery", {})
    cols = int(calib["grid"]["cols"])
    rows = int(calib["grid"]["rows"])
    lw = float(spec.get("label_width_in", 2.625))
    lh = float(spec.get("label_height_in", 1.0))
    top_margin = float(spec.get("top_margin_in", 0.5))
    left_margin = float(spec.get("left_margin_in", 0.1875))
    h_gutter = float(spec.get("h_gutter_in", 0.125))
    v_gutter = float(spec.get("v_gutter_in", 0.0))

    # Apply global calibration offset (mm → in conversion)
    off = calib.get("global_offset_mm", {}) or {}
    off_x_in = float(off.get("x", 0)) / 25.4
    off_y_in = float(off.get("y", 0)) / 25.4

    total = cols * rows

    if recipients:
        entries = recipients[:total]
        while len(entries) < total:
            entries.append({"name": "", "line1": "", "line2": "", "line3": ""})
    else:
        # Default: N copies of the brand return address.
        has_sig = bool(brand.get("signature_name"))
        single = {
            "name":  brand.get("signature_name") or brand.get("org_name", ""),
            "line1": brand.get("org_name", "") if has_sig else brand.get("address_line_1", ""),
            "line2": brand.get("address_line_1", "") if has_sig else brand.get("address_line_2", ""),
            "line3": brand.get("address_line_2", "") if has_sig else "",
        }
        entries = [dict(single) for _ in range(total)]

    out: list[str] = []
    for i, e in enumerate(entries):
        r = i // cols
        c = i % cols
        top_in = top_margin + r * (lh + v_gutter) + off_y_in
        left_in = left_margin + c * (lw + h_gutter) + off_x_in
        name  = _esc_html(e.get("name", ""))
        line1 = _esc_html(e.get("line1", ""))
        line2 = _esc_html(e.get("line2", ""))
        line3 = _esc_html(e.get("line3", ""))

        inner_parts = []
        if name:  inner_parts.append(f'<span class="name line">{name}</span>')
        if line1: inner_parts.append(f'<span class="line">{line1}</span>')
        if line2: inner_parts.append(f'<span class="line">{line2}</span>')
        if line3: inner_parts.append(f'<span class="line">{line3}</span>')
        inner = "".join(inner_parts)

        out.append(
            f'<div class="label" data-i="{i+1}" '
            f'style="top:{top_in:.4f}in;left:{left_in:.4f}in;'
            f'width:{lw}in;height:{lh}in;">{inner}</div>'
        )
    return "\n".join(out)


def _brand_signature_block(brand: dict) -> str:
    """Assemble the signature block HTML from brand config."""
    name = _esc_html(brand.get("signature_name", ""))
    title = _esc_html(brand.get("signature_title", ""))
    org = _esc_html(brand.get("org_name", ""))
    addr = _esc_html(brand.get("address_line_1", ""))
    email = _esc_html(brand.get("email", ""))
    phone = _esc_html(brand.get("phone", ""))
    contact = " &middot; ".join(x for x in [email, phone] if x)
    lines = [
        "With respect and full presence,<br><br>",
        f'<span class="name">{name}</span><br>' if name else "",
        f"{title}<br>" if title else "",
        f"{org}<br>" if org else "",
        f"{addr}<br>" if addr else "",
        contact,
    ]
    return "".join(lines)


# ---------------------------------------------------------------------------
# chrome → pdf → lp
# ---------------------------------------------------------------------------

def html_to_pdf(html: str, out_pdf: Path) -> None:
    tmp_html = out_pdf.with_suffix(".html")
    tmp_html.write_text(html)
    # Try google-chrome first, then chromium
    chrome = None
    for cand in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
        if subprocess.run(["which", cand], capture_output=True).returncode == 0:
            chrome = cand
            break
    if chrome is None:
        raise SystemExit("No Chrome/Chromium found — cannot render PDF.")
    cmd = [
        chrome,
        "--headless",
        "--disable-gpu",
        "--no-pdf-header-footer",
        f"--print-to-pdf={out_pdf}",
        f"file://{tmp_html}",
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stderr, file=sys.stderr)
        raise SystemExit("Chrome PDF render failed.")


def lp_print(pdf: Path, printer: str) -> None:
    printer = validate_printer_name(printer)
    # No fit-to-page: we want 1:1 scale so the grid coordinates match the paper.
    r = subprocess.run(
        ["lp", "-d", printer, "-o", "media=Letter", str(pdf)],
        capture_output=True, text=True,
    )
    if r.returncode != 0:
        print(r.stderr, file=sys.stderr)
        raise SystemExit(f"lp failed for printer {printer}")
    print(r.stdout.strip())


def pdf_to_png(pdf: Path, dpi: int = 150) -> Path:
    """Render the first page of a PDF to a PNG via pdftoppm. Returns the PNG path."""
    prefix = pdf.with_suffix("")
    r = subprocess.run(
        ["pdftoppm", "-r", str(dpi), "-png", "-f", "1", "-l", "1", str(pdf), str(prefix)],
        capture_output=True,
        text=True,
    )
    if r.returncode != 0:
        print(r.stderr, file=sys.stderr)
        raise SystemExit("pdftoppm failed")
    # pdftoppm writes <prefix>-1.png for page 1 (or -01 for >9 pages, but we forced -l 1)
    candidates = [
        Path(f"{prefix}-1.png"),
        Path(f"{prefix}-01.png"),
    ]
    for c in candidates:
        if c.exists():
            return c
    raise SystemExit(f"pdftoppm produced no output near {prefix}")


def scan_to_png(out_png: Path, device: str | None = None, dpi: int = 200) -> Path:
    """Pull a flatbed scan via scanimage and save as PNG. Returns the PNG path."""
    device = device or "airscan:e0:EPSON ET-2800 Series"
    cmd = ["scanimage", "-d", device, "--format=png", f"--resolution={dpi}"]
    with open(out_png, "wb") as f:
        r = subprocess.run(cmd, stdout=f, stderr=subprocess.PIPE)
    if r.returncode != 0:
        print(r.stderr.decode("utf-8", "replace"), file=sys.stderr)
        raise SystemExit("scanimage failed")
    return out_png


# ---------------------------------------------------------------------------
# correction parser
# ---------------------------------------------------------------------------

def parse_correction(calib: dict, correction: str) -> list[str]:
    """Parse a correction string and mutate calib in place. Return list of messages."""
    msgs: list[str] = []
    text = correction.strip()

    # flip lr
    if FLIP_RE.search(text):
        calib["flip_lr"] = not calib.get("flip_lr", False)
        msgs.append(f"flip_lr → {calib['flip_lr']}")

    # shift
    for m in SHIFT_RE.finditer(text):
        direction, amount = m.group(1).lower(), int(m.group(2))
        dx = dy = 0
        col_w_mm = 8.5 * 25.4 / 8
        row_h_mm = 11.0 * 25.4 / 11
        if direction == "up":    dy = -amount * row_h_mm
        if direction == "down":  dy =  amount * row_h_mm
        if direction == "left":  dx = -amount * col_w_mm
        if direction == "right": dx =  amount * col_w_mm
        off = calib.setdefault("global_offset_mm", {"x": 0, "y": 0})
        off["x"] = round(off.get("x", 0) + dx, 2)
        off["y"] = round(off.get("y", 0) + dy, 2)
        msgs.append(f"global_offset_mm → {off}")

    # move ELEMENT to CELL
    for m in MOVE_RE.finditer(text):
        name, target = m.group(1).lower(), m.group(2).lower()
        regions = calib.setdefault("regions", {})
        regions[name] = target
        msgs.append(f"regions.{name} → {target}")

    # CELL → CELL (relative delta)
    for m in ARROW_RE.finditer(text):
        src, dst = m.group(1).lower(), m.group(2).lower()
        (sr, sc) = coord_to_rowcol(src)
        (dr, dc) = coord_to_rowcol(dst)
        col_w_mm = 8.5 * 25.4 / 8
        row_h_mm = 11.0 * 25.4 / 11
        dx_mm = round((dc - sc) * col_w_mm, 2)
        dy_mm = round((dr - sr) * row_h_mm, 2)
        off = calib.setdefault("global_offset_mm", {"x": 0, "y": 0})
        off["x"] = round(off.get("x", 0) + dx_mm, 2)
        off["y"] = round(off.get("y", 0) + dy_mm, 2)
        msgs.append(f"{src} → {dst} (delta: {dx_mm}mm x, {dy_mm}mm y) → global_offset_mm = {off}")

    # CELL=NAME (region assignment)
    for m in ASSIGN_RE.finditer(text):
        cell, name = m.group(1).lower(), m.group(2).lower()
        regions = calib.setdefault("regions", {})
        regions[name] = cell
        msgs.append(f"regions.{name} → {cell}")

    # Line references (captured as notes so nothing is lost)
    v_hits = VLINE_RE.findall(text)
    h_hits = HLINE_RE.findall(text)
    if v_hits or h_hits:
        notes = calib.setdefault("notes", [])
        notes.append({
            "ts": datetime.now().isoformat(timespec="seconds"),
            "raw": correction,
            "v_lines": [f"{a}|{b}".lower() for a, b in v_hits],
            "h_lines": [f"{a}|{b}" for a, b in h_hits],
        })
        if v_hits:
            msgs.append(f"vertical line refs: {', '.join(f'{a}|{b}' for a, b in v_hits)}")
        if h_hits:
            msgs.append(f"horizontal line refs: {', '.join(f'{a}|{b}' for a, b in h_hits)}")

    # Note anything we still don't understand
    if not msgs:
        notes = calib.setdefault("notes", [])
        notes.append({"ts": datetime.now().isoformat(timespec="seconds"), "raw": correction})
        msgs.append(f"(unparsed — saved as note: {correction!r})")

    calib["last_calibrated"] = datetime.now().isoformat(timespec="seconds")
    return msgs


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------

def cmd_list(args) -> None:
    print(f"Runtime root: {ROOT}")
    print(f"System default printer: {current_system_default_printer() or 'unknown'}")
    state = load_state()
    if not state:
        print("No calibration state yet.")
    else:
        for printer, templates in state.items():
            print(f"{printer}:")
            for name in sorted(templates.keys()):
                ts = templates[name].get("last_calibrated") or "—"
                print(f"  {name:<16}  last calibrated: {ts}")
    tmpl_files = sorted(p.stem for p in TEMPLATES.glob("*.html"))
    print("\nTemplates on disk:")
    for t in tmpl_files:
        print(f"  {t}")


def cmd_show(args) -> None:
    args.printer = resolve_printer(args.printer)
    state = load_state()
    calib = get_calib(state, args.printer, args.template)
    print(json.dumps(calib, indent=2))


def cmd_test(args) -> None:
    args.printer = resolve_printer(args.printer)
    allowed, watermark, lic_state = license_gate(args.printer, "test")
    if not allowed:
        raise SystemExit(1)
    state = load_state()
    calib, created = ensure_calib(state, args.printer, args.template)
    if created:
        save_state(state)
    print_calibration_summary("test", args.printer, args.template, calib, created)
    recipients = _load_recipients_csv(Path(args.csv)) if getattr(args, "csv", None) else None
    html = render_template(args.template, calib, args.printer, with_grid=True, watermark=watermark, recipients=recipients)
    TEST_OUT.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf = TEST_OUT / f"{args.template}_TEST_{stamp}.pdf"
    html_to_pdf(html, pdf)
    print(f"rendered: {pdf}")
    outputs = {"pdf": pdf}
    if not args.no_preview:
        png = pdf_to_png(pdf, dpi=args.dpi)
        outputs["preview_png"] = png
        print(f"PREVIEW: {png}")
    manifest = write_job_manifest("test", args.printer, args.template, calib, outputs, created, lic_state)
    print(f"MANIFEST: {manifest}")
    if not args.no_print:
        lp_print(pdf, args.printer)


def cmd_preview(args) -> None:
    """Render the template to PDF + PNG and return the PNG path.

    Does NOT print to paper. The PNG is suitable for Claude to read back via
    the Read tool, closing the layout-iteration loop without using any ink.
    """
    args.printer = resolve_printer(args.printer)
    allowed, watermark, lic_state = license_gate(args.printer, "preview")
    if not allowed:
        raise SystemExit(1)
    state = load_state()
    calib, created = ensure_calib(state, args.printer, args.template)
    if created:
        save_state(state)
    print_calibration_summary("preview", args.printer, args.template, calib, created)
    recipients = _load_recipients_csv(Path(args.csv)) if getattr(args, "csv", None) else None
    html = render_template(args.template, calib, args.printer, with_grid=not args.no_grid, watermark=watermark, recipients=recipients)
    TEST_OUT.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf = TEST_OUT / f"{args.template}_PREVIEW_{stamp}.pdf"
    html_to_pdf(html, pdf)
    png = pdf_to_png(pdf, dpi=args.dpi)
    print(f"PDF:     {pdf}")
    print(f"PREVIEW: {png}")
    manifest = write_job_manifest("preview", args.printer, args.template, calib, {"pdf": pdf, "preview_png": png}, created, lic_state)
    print(f"MANIFEST: {manifest}")
    if args.open:
        subprocess.Popen(["xdg-open", str(png)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def cmd_scan(args) -> None:
    """Pull a physical flatbed scan and save as PNG.

    Runs scanimage against the EPSON ET-2800 Series (via airscan/eSCL by default).
    The returned PNG path is what Claude should Read to compare the physical
    print against the rendered source.
    """
    TEST_OUT.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    tag = args.tag or args.template or "scan"
    out_png = TEST_OUT / f"{tag}_SCAN_{stamp}.png"
    print(f"scanning → {out_png} ({args.dpi} dpi, device={args.device!r}) …")
    scan_to_png(out_png, device=args.device, dpi=args.dpi)
    print(f"SCAN: {out_png}")


def cmd_loop(args) -> None:
    """Full print → scan → report loop.

    1. Render test sheet with grid overlay and print it.
    2. Prompt user to place the paper on the flatbed.
    3. Pull a scan back in as PNG.
    4. Print both the rendered PNG and the scanned PNG paths so Claude can
       compare them side by side via Read.
    """
    args.printer = resolve_printer(args.printer)
    allowed, watermark, lic_state = license_gate(args.printer, "loop")
    if not allowed:
        raise SystemExit(1)
    state = load_state()
    calib, created = ensure_calib(state, args.printer, args.template)
    if created:
        save_state(state)
    print_calibration_summary("loop", args.printer, args.template, calib, created)
    html = render_template(args.template, calib, args.printer, with_grid=True, watermark=watermark)
    TEST_OUT.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf = TEST_OUT / f"{args.template}_LOOP_{stamp}.pdf"
    html_to_pdf(html, pdf)
    rendered_png = pdf_to_png(pdf, dpi=args.dpi)
    print(f"RENDERED: {rendered_png}")
    manifest = write_job_manifest("loop-render", args.printer, args.template, calib, {"pdf": pdf, "rendered_png": rendered_png}, created, lic_state)
    print(f"MANIFEST: {manifest}")
    lp_print(pdf, args.printer)
    input("Place the printed sheet face-down on the flatbed, then press ENTER to scan…")
    scan_png = TEST_OUT / f"{args.template}_LOOP_SCAN_{stamp}.png"
    scan_to_png(scan_png, device=args.device, dpi=args.dpi)
    print(f"SCANNED:  {scan_png}")
    print("Compare side by side with: Read tool on both paths above.")


def cmd_collide(args) -> None:
    """Detect content collision with the gold footer border in a rendered PDF.

    Why this exists: at preview DPI the human eye (or Claude's eye) can miss a
    situation where body text overlaps the thin gold footer border line —
    technically the page renders, but on paper the gold line runs THROUGH a
    word and you find out only after burning a sheet. This command catches it
    programmatically.

    How it works:
      1. Render the PDF's first page to PNG at 220 dpi
      2. Scan the bottom 20% of the page for rows that are >60% gold (#b8860b)
      3. The top-most such row is the footer strip's border line
      4. Inspect the N pixels immediately ABOVE that border line (the 'safe
         zone') — nothing should live there, it's the gap between the grid
         content and the footer
      5. Count dark pixels in that zone. If count exceeds threshold, flag it
         as a collision and report y-coordinate + approximate severity
      6. Exit 0 if clean, 1 if collision detected (so it can gate CI / print)

    Usage:
      waiste-not collide path/to/slide.pdf
      waiste-not collide path/to/slide.pdf --safe-zone 15 --threshold 100
      waiste-not collide path/to/slide.pdf --dpi 300 --verbose
    """
    try:
        from PIL import Image
    except ImportError:
        raise SystemExit("Pillow required: pip install Pillow")

    pdf = Path(args.pdf)
    if not pdf.exists():
        raise SystemExit(f"No such file: {pdf}")

    # Render to PNG at specified DPI
    png = pdf_to_png(pdf, dpi=args.dpi)
    img = Image.open(png).convert("RGB")
    w, h = img.size
    px = img.load()

    def is_gold(r, g, b):
        # #b8860b ≈ (184, 134, 11). Allow generous tolerance for JPEG-ish bleed.
        return 140 <= r <= 220 and 95 <= g <= 175 and b <= 70

    def is_dark(r, g, b):
        return r < 110 and g < 110 and b < 110

    # Scan bottom 20% of page for horizontal gold runs (the border)
    scan_start = int(h * 0.80)
    gold_rows = []
    for y in range(scan_start, h):
        gold_count = 0
        for x in range(w):
            if is_gold(*px[x, y]):
                gold_count += 1
        if gold_count > w * 0.40:
            gold_rows.append((y, gold_count))

    if not gold_rows:
        print(f"[collide] {pdf.name}: no gold footer border detected in bottom 20% — skipping")
        return

    # Use the gold row with the highest gold count (the solid border line)
    border_y, border_gold = max(gold_rows, key=lambda t: t[1])
    border_from_bottom_in = (h - border_y) / args.dpi

    # Safe zone: N pixels above the border. Nothing should live here — this is
    # the gap between grid content and the footer strip.
    safe_px = args.safe_zone
    zone_above_top = max(0, border_y - safe_px)

    # How much of the border row itself is dark (text crossing the gold line)?
    on_border_dark = 0
    for x in range(w):
        if is_dark(*px[x, border_y]):
            on_border_dark += 1

    # "Dense text row" heuristic for the above-zone. A row qualifies as a
    # text-overflow row if:
    #   (a) it has ≥ row_dark_min dark pixels, AND
    #   (b) its dark density (dark_px / span) is below max_density — filled
    #       backgrounds (navy stat-strips, dark callouts) have density ~0.9+,
    #       while glyph rows on white background sit around 0.1–0.3.
    # A vertical table border crossing fails (a) because it's only a handful
    # of pixels total. A navy rectangle fails (b) because it's near-solid.
    # Actual overflowed text passes both and gets flagged.
    text_row_threshold = args.row_dark_min
    max_density = args.max_density
    bad_rows = []
    for y in range(zone_above_top, border_y):
        row_dark = 0
        first_x = None
        last_x = 0
        for x in range(w):
            if is_dark(*px[x, y]):
                row_dark += 1
                if first_x is None:
                    first_x = x
                last_x = x
        if row_dark >= text_row_threshold:
            span = (last_x - first_x + 1) if first_x is not None else 1
            density = row_dark / span if span > 0 else 0.0
            if density < max_density:
                span_in = span / args.dpi
                bad_rows.append((y, row_dark, first_x or 0, last_x, span_in, density))

    hit_border = on_border_dark > args.border_threshold
    hit_above = len(bad_rows) > 0

    if args.verbose:
        print(f"[collide] {pdf.name}")
        print(f"  image:          {w}×{h} px @ {args.dpi} dpi")
        print(f"  gold border y:  {border_y} ({border_from_bottom_in:.2f}in from bottom, {border_gold}px gold)")
        print(f"  safe zone:      y={zone_above_top}..{border_y} ({safe_px}px above border)")
        print(f"  on-border dark: {on_border_dark}  (threshold {args.border_threshold})")
        print(f"  text rows above:{len(bad_rows)}  (row needs ≥{text_row_threshold} dark px to count)")
        for y, rd, fx, lx, span, dens in bad_rows[:5]:
            dy = y - border_y
            print(f"    dy={dy:+4d} y={y}: {rd} dark px, span {span:.2f}in, density {dens:.2f}")
        if len(bad_rows) > 5:
            print(f"    … and {len(bad_rows) - 5} more text rows")
    else:
        tag = "BLEED " if (hit_border or hit_above) else "CLEAN "
        detail = ""
        if hit_border:
            detail += f" line-through={on_border_dark}"
        if hit_above:
            detail += f" overflow_rows={len(bad_rows)}"
        print(f"[collide] {tag} {pdf.name}:{detail or ' ok'}")

    if hit_border or hit_above:
        if hit_border:
            border_xs = [x for x in range(w) if is_dark(*px[x, border_y])]
            if border_xs:
                print(f"  line-through: text crossing border at x={border_xs[0]/args.dpi:.2f}..{border_xs[-1]/args.dpi:.2f}in")
        if hit_above:
            y, rd, fx, lx, span, dens = bad_rows[0]
            print(f"  overflow:     topmost text row at y={y} (dy={y-border_y:+d}), {rd} px, span {span:.2f}in, density {dens:.2f}")
        print(f"  hint: trim column content, shrink callout text, or reduce grid height")
        raise SystemExit(1)


def cmd_fix(args) -> None:
    args.printer = resolve_printer(args.printer)
    state = load_state()
    calib, _created = ensure_calib(state, args.printer, args.template)
    msgs = parse_correction(calib, args.correction)
    save_state(state)
    print(f"Correction applied to {args.printer}/{args.template}:")
    for m in msgs:
        print(f"  · {m}")
    print_calibration_summary("fix", args.printer, args.template, calib)


def cmd_render(args) -> None:
    args.printer = resolve_printer(args.printer)
    allowed, watermark, lic_state = license_gate(args.printer, "render")
    if not allowed:
        raise SystemExit(1)
    state = load_state()
    calib, created = ensure_calib(state, args.printer, args.template)
    if created:
        save_state(state)
    print_calibration_summary("render", args.printer, args.template, calib, created)
    content: dict = {}
    if args.content:
        # Minimal: read markdown, stuff into BODY, leave other slots as defaults
        body_md = Path(args.content).read_text()
        try:
            import markdown
            body_html = _strip_unsafe_html(markdown.markdown(body_md))
        except ImportError:
            body_html = "<pre>" + body_md.replace("<", "&lt;") + "</pre>"
        content["BODY"] = body_html
    recipients = _load_recipients_csv(Path(args.csv)) if getattr(args, "csv", None) else None
    html = render_template(args.template, calib, args.printer, content=content, with_grid=False, watermark=watermark, recipients=recipients)
    out = Path(args.out)
    html_to_pdf(html, out)
    print(f"rendered: {out}")
    manifest = write_job_manifest("render", args.printer, args.template, calib, {"pdf": out}, created, lic_state)
    print(f"MANIFEST: {manifest}")


def cmd_serve(args) -> None:
    from waiste_not.web import serve
    serve(host=args.host, port=args.port)


def cmd_doctor(args) -> None:
    from waiste_not import license as _lic

    failures = 0

    def check(label: str, ok: bool, detail: str = "") -> None:
        nonlocal failures
        tag = "OK" if ok else "FAIL"
        if not ok:
            failures += 1
        print(f"{tag:<4} {label:<24} {detail}")

    chrome = next((c for c in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser") if shutil.which(c)), None)
    templates = sorted(p.stem for p in TEMPLATES.glob("*.html"))
    profiles = _load_template_profiles()
    state = load_state()
    lic_state = _lic.status(LICENSE_FILE, ROOT / ".trial_start")
    default_printer = current_system_default_printer()
    printers = cups_printers()

    print("WAIste Not doctor")
    print(f"root:        {ROOT}")
    print(f"templates:   {TEMPLATES}")
    print(f"state:       {STATE_FILE}")
    print(f"license:     {LICENSE_FILE}")
    print()

    check("runtime root", ROOT.exists(), str(ROOT))
    check("templates dir", TEMPLATES.exists(), str(TEMPLATES))
    check("templates present", bool(templates), ", ".join(templates) or "none")
    missing_profiles = [t for t in templates if t not in profiles and not _template_profile_from_state(state, t)]
    check("default profiles", not missing_profiles, ", ".join(missing_profiles) if missing_profiles else "all templates covered")
    check("brand config", BRAND_FILE.exists(), str(BRAND_FILE))
    check("calibration state", STATE_FILE.exists(), str(STATE_FILE))
    check("Chrome/Chromium", chrome is not None, chrome or "required for PDF rendering")
    check("pdftoppm", shutil.which("pdftoppm") is not None, shutil.which("pdftoppm") or "required for PNG previews")
    check("lp command", shutil.which("lp") is not None, shutil.which("lp") or "required for printing")
    check("CUPS printers", bool(printers), ", ".join(printers) or "none")
    check("system default", default_printer is not None, default_printer or "none")
    print(f"license mode: {lic_state['mode']} printers_allowed={lic_state['printers_allowed']} watermark={lic_state['watermark']}")
    print(f"machine:      {_lic.machine_fingerprint()}")

    if failures:
        raise SystemExit(1)


def cmd_license(args) -> None:
    from waiste_not import license as _lic
    trial_file = ROOT / ".trial_start"

    if args.action == "fingerprint":
        print(_lic.machine_fingerprint())
        return

    if args.action == "status":
        state = _lic.status(LICENSE_FILE, trial_file)
        calib_state = load_state()
        current_printers = [k for k in calib_state.keys() if not k.startswith("_")]
        print(f"mode:             {state['mode']}")
        print(f"machine:          {_lic.machine_fingerprint()}")
        print(f"printers allowed: {state['printers_allowed']}")
        print(f"printers active:  {len(current_printers)}  {current_printers}")
        if state["mode"] == "trial":
            print(f"days remaining:   {state['days_remaining']}")
        if state["mode"] == "licensed":
            print(f"issued:           {state.get('issued', '?')}")
            print(f"email:            {state.get('email', '-')}")
        print(f"watermark:        {state['watermark']}")
        return

    if args.action == "activate":
        try:
            payload = _lic.save_license(LICENSE_FILE, args.key)
        except ValueError as e:
            raise SystemExit(f"Activation failed: {e}")
        print(f"✓ Activated. {payload['printers']} printer license for {payload.get('email', '-')}.")
        return

    if args.action == "issue":
        # Vendor-side: generate a key for a fingerprint (defaults to THIS machine).
        key = _lic.issue_key(
            printers=args.printers,
            email=args.email or "",
            mid=args.fp,
        )
        print(key)
        return

    raise SystemExit(f"unknown license action: {args.action!r}")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("list", help="List templates and calibration state")
    sp.set_defaults(func=cmd_list)

    sp = sub.add_parser("show", help="Show calibration for a template")
    sp.add_argument("template")
    sp.add_argument("--printer", default=None, help="Printer profile (default: CUPS default printer)")
    sp.set_defaults(func=cmd_show)

    sp = sub.add_parser("test", help="Render + print a grid overlay test sheet")
    sp.add_argument("template")
    sp.add_argument("--printer", default=None, help="Printer profile (default: CUPS default printer)")
    sp.add_argument("--no-print", action="store_true", help="Render PDF only, do not send to lp")
    sp.add_argument("--no-preview", action="store_true", help="Do not produce a PNG proof before printing")
    sp.add_argument("--dpi", type=int, default=150, help="PNG proof DPI (default 150)")
    sp.add_argument("--csv", default=None, help="For Avery templates: recipient list CSV (name,line1,line2,line3)")
    sp.set_defaults(func=cmd_test)

    sp = sub.add_parser("fix", help="Apply a correction in grid grammar")
    sp.add_argument("template")
    sp.add_argument("correction")
    sp.add_argument("--printer", default=None, help="Printer profile (default: CUPS default printer)")
    sp.set_defaults(func=cmd_fix)

    sp = sub.add_parser("render", help="Render clean (no grid) with current calibration")
    sp.add_argument("template")
    sp.add_argument("--content", help="Markdown file to drop into BODY")
    sp.add_argument("--out", required=True, help="Output PDF path")
    sp.add_argument("--printer", default=None, help="Printer profile (default: CUPS default printer)")
    sp.add_argument("--csv", default=None, help="For Avery templates: recipient list CSV (name,line1,line2,line3)")
    sp.set_defaults(func=cmd_render)

    sp = sub.add_parser("preview", help="Dry-run: render to PDF + PNG for Claude to see, no printing")
    sp.add_argument("template")
    sp.add_argument("--printer", default=None, help="Printer profile (default: CUPS default printer)")
    sp.add_argument("--no-grid", action="store_true", help="Preview clean layout without grid overlay")
    sp.add_argument("--dpi", type=int, default=150, help="PNG render DPI (default 150)")
    sp.add_argument("--open", action="store_true", help="Open PNG in image viewer for Rhet")
    sp.add_argument("--csv", default=None, help="For Avery templates: recipient list CSV (name,line1,line2,line3)")
    sp.set_defaults(func=cmd_preview)

    sp = sub.add_parser("shoot", help="Alias for preview: shoot a PNG proof back to the operator")
    sp.add_argument("template")
    sp.add_argument("--printer", default=None, help="Printer profile (default: CUPS default printer)")
    sp.add_argument("--no-grid", action="store_true", help="Preview clean layout without grid overlay")
    sp.add_argument("--dpi", type=int, default=150, help="PNG render DPI (default 150)")
    sp.add_argument("--open", action="store_true", help="Open PNG in image viewer for Rhet")
    sp.add_argument("--csv", default=None, help="For Avery templates: recipient list CSV (name,line1,line2,line3)")
    sp.set_defaults(func=cmd_preview)

    sp = sub.add_parser("scan", help="Pull a flatbed scan via scanimage and save as PNG")
    sp.add_argument("--template", default=None, help="Associate scan with a template name (for filename)")
    sp.add_argument("--tag", default=None, help="Custom filename tag")
    sp.add_argument("--device", default="airscan:e0:EPSON ET-2800 Series",
                    help="SANE device (default: airscan:e0:EPSON ET-2800 Series)")
    sp.add_argument("--dpi", type=int, default=200, help="Scan DPI (default 200)")
    sp.set_defaults(func=cmd_scan)

    sp = sub.add_parser("loop", help="Full print → scan → compare loop")
    sp.add_argument("template")
    sp.add_argument("--printer", default=None, help="Printer profile (default: CUPS default printer)")
    sp.add_argument("--device", default="airscan:e0:EPSON ET-2800 Series")
    sp.add_argument("--dpi", type=int, default=200)
    sp.set_defaults(func=cmd_loop)

    sp = sub.add_parser(
        "collide",
        help="Detect content crossing the gold footer border (zero-waste overlap check)",
    )
    sp.add_argument("pdf", help="PDF file to inspect (any PDF with a gold footer border)")
    sp.add_argument("--dpi", type=int, default=220,
                    help="Render DPI for pixel inspection (default 220)")
    sp.add_argument("--safe-zone", type=int, default=50,
                    help="Pixels above the border to inspect (default 50 ≈ 0.23in @ 220dpi)")
    sp.add_argument("--border-threshold", type=int, default=40,
                    help="Max dark pixels allowed on the border row itself (default 40)")
    sp.add_argument("--row-dark-min", type=int, default=200,
                    help="Min dark pixels per row to count as a real text row (default 200)")
    sp.add_argument("--max-density", type=float, default=0.5,
                    help="Max dark-pixel density (0–1) before row is treated as a solid background, not text (default 0.5)")
    sp.add_argument("--verbose", "-v", action="store_true",
                    help="Print full diagnostic output")
    sp.set_defaults(func=cmd_collide)

    sp = sub.add_parser("serve", help="Launch the Flask web UI on localhost:8478")
    sp.add_argument("--host", default="127.0.0.1")
    sp.add_argument("--port", type=int, default=8478)
    sp.set_defaults(func=cmd_serve)

    sp = sub.add_parser("doctor", help="Check runtime files, dependencies, printers, and license state")
    sp.set_defaults(func=cmd_doctor)

    # License management
    sp = sub.add_parser("license", help="Manage WAIste Not license (status/activate/fingerprint/issue)")
    lic_sub = sp.add_subparsers(dest="action", required=True)

    lic_sub.add_parser("status", help="Show current license state")
    lic_sub.add_parser("fingerprint", help="Print this machine's fingerprint for license issuance")

    lp = lic_sub.add_parser("activate", help="Activate a license key received from the vendor")
    lp.add_argument("key", help="License key (WN1-...-...)")

    li = lic_sub.add_parser("issue", help="Vendor-side: issue a license key")
    li.add_argument("printers", type=int, help="Number of printers to license")
    li.add_argument("--fp", default=None, help="Buyer's machine fingerprint (omit = this machine)")
    li.add_argument("--email", default="", help="Buyer's email (for receipts)")

    sp.set_defaults(func=cmd_license)

    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
