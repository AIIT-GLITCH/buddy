"""
WAIste Not — license module.

Royalty model: $5 per printer, per machine, one-time activation.

A license key is a base32-encoded, Ed25519-signed payload binding:
    - machine fingerprint (CPU + primary MAC hash)
    - allowed printer count (integer)
    - issue date
    - buyer's email (optional, for receipts)

Trial mode: 7 days, up to 2 printers, "WAIste Not Trial" watermark on every print.
After expiry, `test`/`render`/`preview` refuse to run on unlicensed printers.

Format:
    WN1-<base32-payload>-<base32-sig>

Payload JSON:
    {
      "v": 1,
      "mid": "<16-char machine id hash>",
      "printers": 5,
      "issued": "2026-04-10",
      "email": "office@example.com"
    }

Sig: Ed25519(payload_bytes, vendor_private_key) → base32.

The packaged client ships only the public verification key. Vendor-side key
issuance requires WAISTE_NOT_PRIVATE_KEY, WAISTE_NOT_PRIVATE_KEY_FILE, or the
default private-key file at ~/.waiste_not_vendor_ed25519.pem.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import platform
import re
import subprocess
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)


# ---------------------------------------------------------------------------
# constants
# ---------------------------------------------------------------------------

PUBLIC_KEY_B64 = "xw3vI87r/KuZuMtKFJnOgsTxF1ogHEOIh0u6VFHetkg="
PRIVATE_KEY_ENV = "WAISTE_NOT_PRIVATE_KEY"
PRIVATE_KEY_FILE_ENV = "WAISTE_NOT_PRIVATE_KEY_FILE"
DEFAULT_PRIVATE_KEY_FILE = Path.home() / ".waiste_not_vendor_ed25519.pem"
TRIAL_DAYS = 7
TRIAL_PRINTERS = 2
WATERMARK_TEXT = "WAIste Not — Unlicensed Trial"
KEY_PREFIX = "WN1"


# ---------------------------------------------------------------------------
# machine fingerprint
# ---------------------------------------------------------------------------

def _primary_mac() -> str:
    """Return the MAC address as a hex string (no separators)."""
    # uuid.getnode() returns 48-bit MAC as int; stable within one machine
    return f"{uuid.getnode():012x}"


def _cpu_identifier() -> str:
    """Return a stable CPU identifier — falls back to platform.processor()."""
    # Linux: /proc/cpuinfo model name is stable per hardware
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.lower().startswith("model name"):
                    return line.split(":", 1)[1].strip()
    except (FileNotFoundError, PermissionError):
        pass
    return platform.processor() or platform.machine() or "unknown"


def machine_fingerprint() -> str:
    """Return a stable 16-char machine ID for license binding."""
    material = f"{_primary_mac()}|{_cpu_identifier()}|{platform.node()}"
    h = hashlib.sha256(material.encode()).hexdigest()
    return h[:16]


# ---------------------------------------------------------------------------
# key encoding
# ---------------------------------------------------------------------------

def _b32(b: bytes) -> str:
    return base64.b32encode(b).decode().rstrip("=")


def _unb32(s: str) -> bytes:
    pad = "=" * ((8 - len(s) % 8) % 8)
    return base64.b32decode(s + pad)


def _public_key() -> Ed25519PublicKey:
    return Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64))


def _load_private_key() -> Ed25519PrivateKey:
    inline = os.environ.get(PRIVATE_KEY_ENV)
    path = Path(os.environ.get(PRIVATE_KEY_FILE_ENV, DEFAULT_PRIVATE_KEY_FILE)).expanduser()

    if inline:
        raw = inline.encode()
    elif path.exists():
        raw = path.read_bytes()
    else:
        raise RuntimeError(
            "Missing vendor private key. Set WAISTE_NOT_PRIVATE_KEY, "
            "WAISTE_NOT_PRIVATE_KEY_FILE, or create "
            f"{DEFAULT_PRIVATE_KEY_FILE}."
        )

    key = serialization.load_pem_private_key(raw, password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise RuntimeError("Vendor private key must be an Ed25519 private key.")
    return key


def _sign(payload_bytes: bytes) -> bytes:
    return _load_private_key().sign(payload_bytes)


def _verify(payload_bytes: bytes, sig: bytes) -> bool:
    try:
        _public_key().verify(sig, payload_bytes)
    except InvalidSignature:
        return False
    return True


def issue_key(printers: int, email: str = "", issued: date | None = None, mid: str | None = None) -> str:
    """Issue a license key bound to a machine fingerprint.

    Vendor use: pass `mid` from the buyer so the key is bound to THEIR machine.
    If omitted, binds to the current machine (useful for dev + single-box
    installs where vendor and buyer are the same person).
    """
    mid = mid or machine_fingerprint()
    payload = {
        "v": 1,
        "mid": mid,
        "printers": int(printers),
        "issued": (issued or date.today()).isoformat(),
        "email": email,
    }
    payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    sig = _sign(payload_bytes)
    return f"{KEY_PREFIX}-{_b32(payload_bytes)}-{_b32(sig)}"


def parse_key(key: str) -> dict | None:
    """Parse and verify a license key. Returns payload dict or None."""
    key = (key or "").strip().upper().replace(" ", "")
    m = re.fullmatch(rf"{KEY_PREFIX}-([A-Z2-7]+)-([A-Z2-7]+)", key)
    if not m:
        return None
    try:
        payload_bytes = _unb32(m.group(1))
        sig = _unb32(m.group(2))
    except Exception:
        return None
    if not _verify(payload_bytes, sig):
        return None
    try:
        payload = json.loads(payload_bytes.decode())
    except Exception:
        return None
    if payload.get("mid") != machine_fingerprint():
        # Key was issued for a different machine — reject.
        return None
    return payload


# ---------------------------------------------------------------------------
# license state
# ---------------------------------------------------------------------------

def load_license(license_file: Path) -> dict | None:
    if not license_file.exists():
        return None
    return parse_key(license_file.read_text())


def save_license(license_file: Path, key: str) -> dict:
    payload = parse_key(key)
    if not payload:
        raise ValueError("Invalid license key (bad signature, wrong machine, or corrupt).")
    license_file.write_text(key.strip() + "\n")
    return payload


def status(license_file: Path, trial_start_file: Path) -> dict:
    """Return a dict describing the current license state.

    Keys:
        mode: "licensed" | "trial" | "expired"
        printers_allowed: int
        days_remaining: int (trial only)
        email: str (licensed only)
        watermark: bool
    """
    payload = load_license(license_file)
    if payload:
        return {
            "mode": "licensed",
            "printers_allowed": payload["printers"],
            "issued": payload["issued"],
            "email": payload.get("email", ""),
            "watermark": False,
        }

    # Trial path — start on first run
    if not trial_start_file.exists():
        trial_start_file.write_text(date.today().isoformat() + "\n")
    try:
        start = date.fromisoformat(trial_start_file.read_text().strip())
    except Exception:
        start = date.today()
        trial_start_file.write_text(start.isoformat() + "\n")

    days_used = (date.today() - start).days
    days_remaining = max(0, TRIAL_DAYS - days_used)
    if days_remaining > 0:
        return {
            "mode": "trial",
            "printers_allowed": TRIAL_PRINTERS,
            "days_remaining": days_remaining,
            "watermark": True,
        }
    return {
        "mode": "expired",
        "printers_allowed": 0,
        "days_remaining": 0,
        "watermark": True,
    }


def is_printer_allowed(state: dict, printer_name: str, current_printers: list[str]) -> bool:
    """Check if printing to `printer_name` is allowed under the current license."""
    allowed = state["printers_allowed"]
    if state["mode"] == "expired":
        return False
    if printer_name in current_printers:
        return True  # already activated under the allowance
    return len(current_printers) < allowed


def watermark_css() -> str:
    """CSS that stamps the unlicensed-trial watermark on every page."""
    return f"""
    body::before {{
      content: "{WATERMARK_TEXT}";
      position: fixed;
      top: 45%;
      left: 50%;
      transform: translate(-50%, -50%) rotate(-30deg);
      font-size: 64pt;
      color: rgba(200, 0, 0, 0.12);
      font-family: Georgia, serif;
      font-weight: bold;
      pointer-events: none;
      z-index: 99998;
      white-space: nowrap;
    }}
    """


def verified_stamp_css() -> str:
    """CSS that stamps a small 'Verified by wAIste Not' badge on every page.
    Bottom-right corner, subtle but visible. Shows the system was used."""
    return """
    body::after {
      content: "\\2713  Verified by wAIste Not";
      position: fixed;
      bottom: 12pt;
      right: 16pt;
      font-size: 7pt;
      color: rgba(80, 80, 80, 0.55);
      font-family: 'Courier New', monospace;
      letter-spacing: 0.5pt;
      pointer-events: none;
      z-index: 99997;
      border: 0.5pt solid rgba(80, 80, 80, 0.3);
      padding: 2pt 6pt;
      border-radius: 2pt;
    }
    """
