"""WAIste Not — AI Print Formation.

Waste nothing. Print everything right the first time.

Grid-based calibration + brand-locked templates for every printer in your office.
Offline. Private. $5 per printer. Forever.
"""

__version__ = "0.1.0"
__tagline__ = "AI Print Formation — Waste Nothing"
