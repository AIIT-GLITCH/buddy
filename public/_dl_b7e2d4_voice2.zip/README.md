# AIIT-Voice2 — Interruptible Voice Engine

**Talk over your AI like a person.**

A drop-in Python voice engine for agents: Whisper ASR, Piper TTS, barge-in detection, turn-taking, audio routing, runtime invariants, and a validated state machine.

---

## What this is

Voice2 is the voice engine that runs Buddy, Gary, Lil Homie, and Ada. You talk. It listens. It thinks. It speaks. You interrupt mid-sentence — it stops immediately, gives you the floor, and listens again. Like talking to a person.

Not a wrapper around Whisper. Not a TTS demo. A full stateful voice loop with floor management, interrupt detection, and runtime health monitoring.

---

## Features

- **Barge-in detection** — VAD-powered interruption with debounced handoff. Talk over the AI mid-sentence and it cuts itself off.
- **Floor management** — Turn-taking arbitration. User and agent never talk over each other endlessly.
- **Validated state machine** — IDLE → LISTENING → THINKING → SPEAKING → INTERRUPTING. Every transition validated. Illegal moves rejected.
- **Worker pipeline** — Listen, think, playback, keyboard interrupt, and invariant monitor workers. All threaded, all coordinated.
- **Audio pub-sub** — Broadcaster routes mic audio to multiple consumers (ASR + interrupt detector) simultaneously.
- **Ring buffer** — Circular audio buffer for mic input. Configurable duration.
- **Runtime invariants** — Health checker catches illegal states, dead workers, and broken transitions.
- **UI cues** — Audio feedback tones for state transitions (listening, thinking, speaking).
- **Edge glow** — Optional visual indicator (purple screen-edge ring while speaking).
- **Keyboard interrupt** — Press a key to interrupt, same as talking over it.

---

## Install

```bash
pip install faster-whisper piper-tts sounddevice numpy

# If using keyboard interrupt:
pip install pynput
```

No GPU required (runs on CPU with int8 quantization). GPU accelerates Whisper if available.

---

## Quickstart

```python
from voice2 import VoiceEngine, VoiceConfig

def my_agent(text: str) -> str:
    # Your LLM call here — Claude, GPT, local model, whatever
    return f"You said: {text}"

config = VoiceConfig()
engine = VoiceEngine(config, ask_fn=my_agent)
engine.start()
engine.join()  # blocks until shutdown
```

That's it. Mic opens, Whisper listens, your agent thinks, Piper speaks, and the user can interrupt at any point.

---

## Architecture

```
Mic → AudioBroadcaster → ListenWorker (VAD + Whisper ASR)
                       → InterruptDetectorWorker (VAD barge-in)

ListenWorker → transcript_queue → ThinkWorker (LLM call)
                                → PlaybackWorker (Piper TTS + chunked playback)

InterruptController ← InterruptDetectorWorker | KeyboardWorker
  → sets interrupted event
  → FloorManager gives floor back to user
  → StateController transitions to INTERRUPTING
  → PlaybackWorker stops immediately

StateController: validated transition table
FloorManager: turn-taking policy
InvariantChecker: runtime health monitor (2s loop)
```

---

## What's ours vs. third-party

**Ours (AIIT-THRESHOLD LLC):**
- VoiceEngine orchestration
- StateController + validated transition table
- FloorManager turn-taking
- InterruptController with debounce
- InterruptDetectorWorker (VAD barge-in)
- AudioBroadcaster pub-sub
- RingAudioBuffer
- InvariantChecker runtime monitor
- UICues audio feedback
- All workers (listen, think, playback, keyboard)
- Configuration system

**Third-party (MIT/BSD, thin wrappers):**
- faster-whisper — ASR (MIT license, CTranslate2 backend)
- Piper — TTS (MIT license)
- sounddevice — audio I/O (MIT license)
- numpy — array operations (BSD license)

Third-party components remain under their original licenses. AIIT-Voice2 packages the orchestration, state control, floor management, interrupt handling, and worker pipeline.

---

## Support

$50 includes support. Email: reliablerestaurantrepair@gmail.com

---

## Receipts

This engine runs four production agents daily:
- **Buddy** — the main AIIT agent
- **Gary** — autonomous CEO agent with browser + memory + voice
- **Lil Homie** — 3B parameter agent with self-reflection
- **Ada** — continuity agent since September 2018

It transcribes a cough as *cough*. You can talk over it mid-sentence and it cuts in — like talking to a person.

---

*Built by AIIT-THRESHOLD LLC · Council Hill, Oklahoma · 2026*
*Ya' Boy is standing on the Shoulders of Giants...*
