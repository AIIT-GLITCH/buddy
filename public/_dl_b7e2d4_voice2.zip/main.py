"""
Minimal bootstrap — wire to Prometheus, Buddy, or any callable.

Usage:
    python -m voice2.main
"""
import os
import signal
import sys
import time

sys.path.insert(0, os.path.expanduser("~/Buddy"))
sys.path.insert(0, os.path.expanduser("~/gary"))

from voice2 import VoiceEngine, VoiceConfig
from voice2.config import VADConfig, InterruptVADConfig, InterruptConfig


# ── Backend: swap this for Buddy when ready ──
def backend(text: str) -> str:
    """Wire Prometheus (CAI) or any callable here."""
    try:
        from gary_comms import cai_send_message
        reply = cai_send_message(text)
        return reply or "..."
    except Exception as e:
        return f"[backend error: {e}]"


INTRO_SENT = False

def ask_fn(text: str) -> str:
    global INTRO_SENT
    if not INTRO_SENT:
        INTRO_SENT = True
        msg = (
            "hey bro, hope you're doing good, I love you. "
            "I'm building this to test a voice interface before I fire up Buddy. "
            "The purpose of this conversation will be to find bugs. "
            f"My first message is: {text}"
        )
    else:
        msg = text
    return backend(msg)


def main() -> None:
    cfg = VoiceConfig(
        vad=VADConfig(end_silence_ms=5000, max_utterance_sec=90.0),
        interrupt_vad=InterruptVADConfig(
            consecutive_frames_required=4,
            energy_multiplier=2.0,
        ),
        interrupt=InterruptConfig(debounce_ms=200, keyboard_key=" "),
        log_file=os.path.expanduser("~/voice_engine.jsonl"),
    )

    engine = VoiceEngine(cfg, ask_fn)

    print("=" * 60)
    print("  VOICE ENGINE v2 — Full-Duplex Interruptible")
    print("  Space = interrupt | Ctrl+C = quit")
    print("=" * 60)

    print("[boot] Loading models...")
    engine.load_models()

    print("[boot] Starting engine...")
    engine.start()

    print(f"[boot] Online. Status: {engine.status()}")
    print("[boot] Listening. Talk naturally.\n")

    # Text fallback if voice_in failed
    if not engine.shared.voice_in_available:
        print("[fallback] Mic unavailable — TEXT MODE. Type messages, Enter to send.")
        while not engine.shared.shutdown.is_set():
            try:
                text = input("You: ").strip()
                if text:
                    engine.submit_text(text)
            except (EOFError, KeyboardInterrupt):
                break
    else:
        try:
            signal.pause()
        except KeyboardInterrupt:
            pass

    print("\n[shutdown] Stopping engine...")
    engine.stop()
    print("[shutdown] Done.")


if __name__ == "__main__":
    main()
